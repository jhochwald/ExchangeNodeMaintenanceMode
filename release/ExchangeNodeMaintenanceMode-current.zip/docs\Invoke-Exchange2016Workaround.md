﻿---
external help file: ExchangeNodeMaintenanceMode-help.xml
online version: 
schema: 2.0.0
---

# Invoke-Exchange2016Workaround

## SYNOPSIS
Workaround for Exchange 2016 on Windows Server 2016

## SYNTAX

```
Invoke-Exchange2016Workaround
```

## DESCRIPTION
Workaround for Exchange 2016 on Windows Server 2016

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Invoke-Exchange2016Workaround
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES
This is a quick an dirty one :)

.
LINK
Set-ExchangeNodeMaintenanceModeOn
Set-ExchangeNodeMaintenanceModeOff
Test-ExchangeNodeMaintenanceMode
Invoke-ApplyExchangeCumulativeUpdate

## RELATED LINKS

